#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"enter side of square :";
    cin>>n;
    cout<<"pattern will be : "<<endl;
    for(int i =1 ;i<=n;i++){
        for(int j=1 ; j<=i;j++){
            cout<<"* ";
        }
        cout<<endl;
    }
    return 0;
}