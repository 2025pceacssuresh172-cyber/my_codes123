#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"enter no be printed: ";
    cin>>n;
    cout<<"Pattern will be : "<<endl;
    for(int i=1;i<=n;i++){
        for(int j=1 ; j<=n+1-i;j++){
            cout<<(char)(i+64)<<" ";
        }
        cout<<endl;
    }
    return 0;

}